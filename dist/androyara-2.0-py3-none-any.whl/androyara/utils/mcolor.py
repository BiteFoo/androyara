# coding:utf8
'''
@File    :   mcolor.py
@Author  :   Loopher 
@Version :   1.0
@License :   (C)Copyright 2020-2021,Loopher
@Desc    :   None
'''

light_yellow = '\033[33m'
light_blue = '\033[36m'
yellow = '\033[33m'
pink = '\033[35m'
white = '\033[37m'
red = '\033[31m'
reset = '\033[37m'
green = '\033[32m'
